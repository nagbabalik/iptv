/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.11.14-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: water_station_db
-- ------------------------------------------------------
-- Server version	10.11.14-MariaDB-0+deb12u2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `activity_logs`
--

DROP TABLE IF EXISTS `activity_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `activity_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `store_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `action` varchar(255) NOT NULL,
  `details` text DEFAULT NULL,
  `ip_address` varchar(80) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `activity_logs`
--

LOCK TABLES `activity_logs` WRITE;
/*!40000 ALTER TABLE `activity_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `activity_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `app_settings`
--

DROP TABLE IF EXISTS `app_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `app_settings` (
  `setting_key` varchar(100) NOT NULL,
  `setting_value` text DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`setting_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `app_settings`
--

LOCK TABLES `app_settings` WRITE;
/*!40000 ALTER TABLE `app_settings` DISABLE KEYS */;
INSERT INTO `app_settings` VALUES
('app_api_token','TRINIFILL_APP_2026_SECRET','2026-05-10 13:34:56'),
('backup_dir','/root/trinifill-db-backups','2026-05-09 23:18:56'),
('github_branch','main','2026-05-09 23:18:56'),
('github_repo','iptv','2026-05-10 01:35:45'),
('github_token','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','2026-05-10 01:36:15'),
('github_user','nagbabalik','2026-05-10 01:35:45');
/*!40000 ALTER TABLE `app_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `backup_logs`
--

DROP TABLE IF EXISTS `backup_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `backup_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `filename` varchar(255) NOT NULL,
  `repo` varchar(255) DEFAULT NULL,
  `status` enum('success','failed') DEFAULT 'success',
  `message` text DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `backup_logs`
--

LOCK TABLES `backup_logs` WRITE;
/*!40000 ALTER TABLE `backup_logs` DISABLE KEYS */;
INSERT INTO `backup_logs` VALUES
(1,'latest_water_station_db.sql.gz','nagbabalik/iptv','success','Hourly GitHub backup replaced latest file',NULL,'2026-05-10 01:36:25'),
(2,'latest_water_station_db.sql.gz','nagbabalik/iptv','success','Hourly GitHub backup replaced latest file',NULL,'2026-05-10 14:00:04'),
(3,'latest_water_station_db.sql.gz','nagbabalik/iptv','success','Hourly GitHub backup replaced latest file',NULL,'2026-05-10 15:00:04'),
(4,'latest_water_station_db.sql.gz','nagbabalik/iptv','success','Hourly GitHub backup replaced latest file',NULL,'2026-05-10 16:00:04'),
(5,'latest_water_station_db.sql.gz','nagbabalik/iptv','success','Hourly GitHub backup replaced latest file',NULL,'2026-05-10 17:00:04'),
(6,'latest_water_station_db.sql.gz','nagbabalik/iptv','success','Hourly GitHub backup replaced latest file',NULL,'2026-05-10 18:00:04'),
(7,'latest_water_station_db.sql.gz','nagbabalik/iptv','success','Hourly GitHub backup replaced latest file',NULL,'2026-05-10 19:00:05'),
(8,'latest_water_station_db.sql.gz','nagbabalik/iptv','success','Hourly GitHub backup replaced latest file',NULL,'2026-05-10 20:00:04'),
(9,'latest_water_station_db.sql.gz','nagbabalik/iptv','success','Hourly GitHub backup replaced latest file',NULL,'2026-05-10 21:00:04'),
(10,'latest_water_station_db.sql.gz','nagbabalik/iptv','success','Hourly GitHub backup replaced latest file',NULL,'2026-05-10 22:00:05'),
(11,'latest_water_station_db.sql.gz','nagbabalik/iptv','success','Hourly GitHub backup replaced latest file',NULL,'2026-05-10 23:00:04'),
(12,'latest_water_station_db.sql.gz','nagbabalik/iptv','success','Hourly GitHub backup replaced latest file',NULL,'2026-05-11 00:00:04'),
(13,'latest_water_station_db.sql.gz','nagbabalik/iptv','success','Hourly GitHub backup replaced latest file',NULL,'2026-05-11 01:00:04'),
(14,'latest_water_station_db.sql.gz','nagbabalik/iptv','success','Hourly GitHub backup replaced latest file',NULL,'2026-05-11 02:00:04'),
(15,'latest_water_station_db.sql.gz','nagbabalik/iptv','success','Hourly GitHub backup replaced latest file',NULL,'2026-05-11 03:00:04'),
(16,'latest_water_station_db.sql.gz','nagbabalik/iptv','success','Hourly GitHub backup replaced latest file',NULL,'2026-05-11 04:00:05'),
(17,'latest_water_station_db.sql.gz','nagbabalik/iptv','success','Hourly GitHub backup replaced latest file',NULL,'2026-05-11 05:00:04'),
(18,'latest_water_station_db.sql.gz','nagbabalik/iptv','success','Hourly GitHub backup replaced latest file',NULL,'2026-05-11 06:00:04'),
(19,'latest_water_station_db.sql.gz','nagbabalik/iptv','success','Hourly GitHub backup replaced latest file',NULL,'2026-05-11 07:00:04'),
(20,'latest_water_station_db.sql.gz','nagbabalik/iptv','success','Hourly GitHub backup replaced latest file',NULL,'2026-05-11 08:00:05'),
(21,'latest_water_station_db.sql.gz','nagbabalik/iptv','success','Hourly GitHub backup replaced latest file',NULL,'2026-05-11 09:00:04'),
(22,'latest_water_station_db.sql.gz','nagbabalik/iptv','success','Hourly GitHub backup replaced latest file',NULL,'2026-05-11 10:00:05'),
(23,'latest_water_station_db.sql.gz','nagbabalik/iptv','success','Hourly GitHub backup replaced latest file',NULL,'2026-05-11 11:00:05'),
(24,'latest_water_station_db.sql.gz','nagbabalik/iptv','success','Hourly GitHub backup replaced latest file',NULL,'2026-05-11 12:00:05'),
(25,'latest_water_station_db.sql.gz','nagbabalik/iptv','success','Hourly GitHub backup replaced latest file',NULL,'2026-05-11 13:00:05'),
(26,'latest_water_station_db.sql.gz','nagbabalik/iptv','success','Hourly GitHub backup replaced latest file',NULL,'2026-05-11 14:00:05');
/*!40000 ALTER TABLE `backup_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `borrowed_gallons`
--

DROP TABLE IF EXISTS `borrowed_gallons`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `borrowed_gallons` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `store_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `gallon_type` varchar(100) NOT NULL,
  `qty_borrowed` int(11) NOT NULL DEFAULT 0,
  `qty_returned` int(11) NOT NULL DEFAULT 0,
  `qty_balance` int(11) NOT NULL DEFAULT 0,
  `deposit_amount` decimal(10,2) DEFAULT 0.00,
  `status` enum('borrowed','partial_returned','returned','lost','damaged') DEFAULT 'borrowed',
  `borrowed_at` date DEFAULT NULL,
  `returned_at` date DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `store_id` (`store_id`),
  KEY `customer_id` (`customer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `borrowed_gallons`
--

LOCK TABLES `borrowed_gallons` WRITE;
/*!40000 ALTER TABLE `borrowed_gallons` DISABLE KEYS */;
/*!40000 ALTER TABLE `borrowed_gallons` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customers`
--

DROP TABLE IF EXISTS `customers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `customers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `store_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `name` varchar(150) NOT NULL,
  `phone` varchar(50) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `latitude` varchar(80) DEFAULT NULL,
  `longitude` varchar(80) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `store_id` (`store_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customers`
--

LOCK TABLES `customers` WRITE;
/*!40000 ALTER TABLE `customers` DISABLE KEYS */;
INSERT INTO `customers` VALUES
(1,1,4,'Sample Customer','2222222222','GPS Location: 40.7083411,-73.8102967','40.7083411','-73.8102967','duera','2026-05-09 23:18:56'),
(2,1,NULL,'Myrna','000000','GPS Location: 15.83700072178714,120.43813564186004','15.83700072178714','120.43813564186004','','2026-05-11 03:44:32'),
(4,1,NULL,'Arnold','','GPS Location: 15.83649042296861,120.43846041764996','15.83649042296861','120.43846041764996','Duera','2026-05-11 05:39:13'),
(5,1,NULL,'Simple','','GPS Location: 15.831752672551383,120.44839412013434','15.831752672551383','120.44839412013434','Sapang','2026-05-11 05:45:42'),
(6,1,NULL,'Gural','','GPS Location: 15.817234188580498,120.4564657686671','15.817234188580498','120.4564657686671','Zone 5','2026-05-11 05:53:46'),
(7,1,NULL,'Estabillio','','GPS Location: 15.835968587800139,120.43890062751343','15.835968587800139','120.43890062751343','Duera','2026-05-11 06:38:05'),
(8,1,NULL,'Ping taguiang','','GPS Location: 15.819999716860195,120.45698333258603','15.819999716860195','120.45698333258603','Bunlag 2','2026-05-11 06:54:24');
/*!40000 ALTER TABLE `customers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `deliveries`
--

DROP TABLE IF EXISTS `deliveries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `deliveries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `store_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `assigned_to` int(11) DEFAULT NULL,
  `status` enum('pending','assigned','out_for_delivery','delivered','failed','cancelled') DEFAULT 'pending',
  `delivery_address` text DEFAULT NULL,
  `latitude` varchar(80) DEFAULT NULL,
  `longitude` varchar(80) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `delivered_at` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `store_id` (`store_id`),
  KEY `order_id` (`order_id`),
  KEY `status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `deliveries`
--

LOCK TABLES `deliveries` WRITE;
/*!40000 ALTER TABLE `deliveries` DISABLE KEYS */;
INSERT INTO `deliveries` VALUES
(1,1,1,NULL,'delivered','',NULL,NULL,NULL,'2026-05-10 09:22:05','2026-05-10 00:43:24'),
(2,1,2,NULL,'delivered','GPS Location: 40.7083819,-73.8102847','40.7083819','-73.8102847',NULL,'2026-05-10 23:28:56','2026-05-10 15:00:49'),
(3,1,3,NULL,'cancelled','GPS Location: 40.7083819,-73.8102847','40.7083819','-73.8102847',NULL,NULL,'2026-05-10 15:00:58'),
(4,1,4,NULL,'cancelled','GPS Location: 40.7043236,-73.8101088','40.7043236','-73.8101088',NULL,NULL,'2026-05-10 15:11:24'),
(5,1,5,NULL,'cancelled','Test app address','40.7043236','-73.8101088',NULL,NULL,'2026-05-10 15:13:13'),
(6,1,6,NULL,'cancelled','Test app address','40.7043236','-73.8101088',NULL,NULL,'2026-05-10 15:15:54'),
(7,1,7,NULL,'pending','GPS Location: 40.7083411,-73.8102967','40.7083411','-73.8102967',NULL,NULL,'2026-05-10 15:38:13');
/*!40000 ALTER TABLE `deliveries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `notifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `store_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `role_target` varchar(40) DEFAULT 'all',
  `title` varchar(255) NOT NULL,
  `message` text DEFAULT NULL,
  `type` varchar(40) DEFAULT 'info',
  `is_read` tinyint(1) DEFAULT 0,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `store_id` (`store_id`),
  KEY `user_id` (`user_id`),
  KEY `is_read` (`is_read`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notifications`
--

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
INSERT INTO `notifications` VALUES
(1,1,NULL,'all','New POS order','DEL-20260509204324830 created','order',1,'2026-05-10 00:43:24'),
(2,1,NULL,'all','Order updated','Customer - DEL-20260509204324830 updated','order',1,'2026-05-10 01:02:33'),
(3,1,NULL,'all','Order updated','Customer - DEL-20260509204324830 updated','order',1,'2026-05-10 01:02:56'),
(4,1,NULL,'all','Order updated','Customer - DEL-20260509204324830 updated','order',1,'2026-05-10 01:22:05'),
(5,1,NULL,'all','New app order','Sample Customer created APP-20260510110049628','order',1,'2026-05-10 15:00:49'),
(6,1,NULL,'all','New app order','Sample Customer created APP-20260510110058708','order',1,'2026-05-10 15:00:58'),
(7,1,NULL,'all','New app order','Sample Customer created APP-20260510111124287','order',1,'2026-05-10 15:11:24'),
(8,1,NULL,'all','New app order','Sample Customer created APP-20260510111313758','order',1,'2026-05-10 15:13:13'),
(9,1,NULL,'all','New app order','Sample Customer created APP-20260510111554155','order',1,'2026-05-10 15:15:54'),
(10,1,NULL,'all','Customer cancelled order','Sample Customer cancelled APP-20260510111554155','order',1,'2026-05-10 15:16:46'),
(11,1,NULL,'all','Customer cancelled order','Sample Customer cancelled APP-20260510111313758','order',1,'2026-05-10 15:17:12'),
(12,1,NULL,'all','Customer cancelled order','Sample Customer cancelled APP-20260510111124287','order',1,'2026-05-10 15:19:19'),
(13,1,NULL,'all','Customer cancelled order','Sample Customer cancelled APP-20260510110058708','order',1,'2026-05-10 15:19:28'),
(14,1,NULL,'all','Order updated','Sample Customer - APP-20260510110049628 updated from app','order',1,'2026-05-10 15:28:05'),
(15,1,NULL,'all','Order updated','Sample Customer - APP-20260510110049628 updated from app','order',1,'2026-05-10 15:28:30'),
(16,1,NULL,'all','Order updated','Sample Customer - APP-20260510110049628 updated from app','order',1,'2026-05-10 15:28:56'),
(17,1,NULL,'all','New app order','Sample Customer created APP-20260510113813366','order',1,'2026-05-10 15:38:13');
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_items`
--

DROP TABLE IF EXISTS `order_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `order_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `product_id` int(11) DEFAULT NULL,
  `product_name` varchar(150) NOT NULL,
  `qty` int(11) NOT NULL DEFAULT 1,
  `price` decimal(10,2) NOT NULL DEFAULT 0.00,
  `total` decimal(10,2) NOT NULL DEFAULT 0.00,
  PRIMARY KEY (`id`),
  KEY `order_id` (`order_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_items`
--

LOCK TABLES `order_items` WRITE;
/*!40000 ALTER TABLE `order_items` DISABLE KEYS */;
INSERT INTO `order_items` VALUES
(1,1,1,'Water Refill',1,25.00,25.00),
(2,2,1,'Water Refill',1,25.00,25.00),
(3,3,1,'Water Refill',1,25.00,25.00),
(4,4,3,'Round Container',1,160.00,160.00),
(5,5,1,'Water Refill',1,25.00,25.00),
(6,6,1,'Water Refill',1,25.00,25.00),
(7,7,3,'Round Container',1,160.00,160.00);
/*!40000 ALTER TABLE `order_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `store_id` int(11) NOT NULL,
  `customer_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `order_no` varchar(80) NOT NULL,
  `order_type` enum('walkin','pickup','delivery') DEFAULT 'delivery',
  `status` enum('pending','accepted','preparing','ready_for_pickup','out_for_delivery','delivered','cancelled') DEFAULT 'pending',
  `payment_status` enum('unpaid','partial','paid','debt') DEFAULT 'unpaid',
  `subtotal` decimal(10,2) DEFAULT 0.00,
  `discount` decimal(10,2) DEFAULT 0.00,
  `total` decimal(10,2) DEFAULT 0.00,
  `paid_amount` decimal(10,2) DEFAULT 0.00,
  `balance` decimal(10,2) DEFAULT 0.00,
  `delivery_address` text DEFAULT NULL,
  `latitude` varchar(80) DEFAULT NULL,
  `longitude` varchar(80) DEFAULT NULL,
  `receipt_no` varchar(80) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `completed_at` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `order_no` (`order_no`),
  KEY `store_id` (`store_id`),
  KEY `customer_id` (`customer_id`),
  KEY `user_id` (`user_id`),
  KEY `status` (`status`),
  KEY `payment_status` (`payment_status`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orders`
--

LOCK TABLES `orders` WRITE;
/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
INSERT INTO `orders` VALUES
(1,1,NULL,NULL,'DEL-20260509204324830','delivery','delivered','paid',25.00,0.00,25.00,25.00,0.00,'',NULL,NULL,NULL,2,'2026-05-10 09:22:05','2026-05-10 00:43:24'),
(2,1,1,4,'APP-20260510110049628','delivery','delivered','paid',25.00,0.00,25.00,25.00,0.00,'GPS Location: 40.7083819,-73.8102847','40.7083819','-73.8102847',NULL,4,'2026-05-10 23:28:56','2026-05-10 15:00:49'),
(3,1,1,4,'APP-20260510110058708','delivery','cancelled','unpaid',25.00,0.00,25.00,0.00,0.00,'GPS Location: 40.7083819,-73.8102847','40.7083819','-73.8102847',NULL,4,NULL,'2026-05-10 15:00:58'),
(4,1,1,4,'APP-20260510111124287','delivery','cancelled','unpaid',160.00,0.00,160.00,0.00,0.00,'GPS Location: 40.7043236,-73.8101088','40.7043236','-73.8101088',NULL,4,NULL,'2026-05-10 15:11:24'),
(5,1,1,4,'APP-20260510111313758','delivery','cancelled','unpaid',25.00,0.00,25.00,0.00,0.00,'Test app address','40.7043236','-73.8101088',NULL,4,NULL,'2026-05-10 15:13:13'),
(6,1,1,4,'APP-20260510111554155','delivery','cancelled','unpaid',25.00,0.00,25.00,0.00,0.00,'Test app address','40.7043236','-73.8101088',NULL,4,NULL,'2026-05-10 15:15:54'),
(7,1,1,4,'APP-20260510113813366','delivery','pending','unpaid',160.00,0.00,160.00,0.00,160.00,'GPS Location: 40.7083411,-73.8102967','40.7083411','-73.8102967',NULL,4,NULL,'2026-05-10 15:38:13');
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payments`
--

DROP TABLE IF EXISTS `payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `payments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `store_id` int(11) NOT NULL,
  `order_id` int(11) DEFAULT NULL,
  `customer_id` int(11) DEFAULT NULL,
  `amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `payment_method` varchar(50) DEFAULT 'cash',
  `payment_type` enum('partial','full','debt_payment') DEFAULT 'partial',
  `reference_no` varchar(120) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `received_by` int(11) DEFAULT NULL,
  `receipt_no` varchar(80) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `store_id` (`store_id`),
  KEY `order_id` (`order_id`),
  KEY `customer_id` (`customer_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payments`
--

LOCK TABLES `payments` WRITE;
/*!40000 ALTER TABLE `payments` DISABLE KEYS */;
INSERT INTO `payments` VALUES
(1,1,1,NULL,25.00,'cash','full','','',2,'RCPT-20260509212205882','2026-05-10 01:22:05'),
(2,1,2,1,25.00,'cash','full','','',2,'APP-RCPT-20260510112805152','2026-05-10 15:28:05');
/*!40000 ALTER TABLE `payments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `store_id` int(11) NOT NULL,
  `product_name` varchar(150) NOT NULL,
  `price` decimal(10,2) NOT NULL DEFAULT 0.00,
  `stock` int(11) NOT NULL DEFAULT 0,
  `unit` varchar(50) DEFAULT 'pcs',
  `status` enum('active','disabled') DEFAULT 'active',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `store_id` (`store_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products`
--

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` VALUES
(1,1,'Water Refill',25.00,999,'gallon','active','2026-05-09 23:18:56'),
(2,1,'Slim Container',180.00,50,'pcs','active','2026-05-09 23:18:56'),
(3,1,'Round Container',160.00,50,'pcs','active','2026-05-09 23:18:56');
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `staff_permissions`
--

DROP TABLE IF EXISTS `staff_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `staff_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `module_key` varchar(80) NOT NULL,
  `can_access` tinyint(1) DEFAULT 0,
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_user_module` (`user_id`,`module_key`),
  KEY `user_id` (`user_id`),
  KEY `module_key` (`module_key`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `staff_permissions`
--

LOCK TABLES `staff_permissions` WRITE;
/*!40000 ALTER TABLE `staff_permissions` DISABLE KEYS */;
INSERT INTO `staff_permissions` VALUES
(1,3,'dashboard',0,'2026-05-10 01:39:41'),
(2,3,'products',1,'2026-05-09 23:19:05'),
(3,3,'customers',1,'2026-05-09 23:19:05'),
(4,3,'gallons',1,'2026-05-09 23:19:05'),
(5,3,'orders',1,'2026-05-09 23:19:05'),
(6,3,'pos',1,'2026-05-09 23:19:05'),
(7,3,'deliveries',1,'2026-05-09 23:19:05'),
(8,3,'payments',1,'2026-05-09 23:19:05'),
(9,3,'reports',1,'2026-05-09 23:19:05'),
(10,3,'store_settings',1,'2026-05-09 23:19:05'),
(27,3,'reset',0,'2026-05-10 01:39:41');
/*!40000 ALTER TABLE `staff_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stores`
--

DROP TABLE IF EXISTS `stores`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `stores` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `admin_id` int(11) DEFAULT NULL,
  `store_name` varchar(150) NOT NULL,
  `address` text DEFAULT NULL,
  `phone` varchar(50) DEFAULT NULL,
  `latitude` varchar(80) DEFAULT NULL,
  `longitude` varchar(80) DEFAULT NULL,
  `status` enum('active','disabled') DEFAULT 'active',
  `online_order_enabled` tinyint(1) DEFAULT 1,
  `online_order_start` time DEFAULT '00:00:00',
  `online_order_end` time DEFAULT '23:59:59',
  `online_order_message` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stores`
--

LOCK TABLES `stores` WRITE;
/*!40000 ALTER TABLE `stores` DISABLE KEYS */;
INSERT INTO `stores` VALUES
(1,2,'Trinifill Water Station','Sample Store Address','1111111111',NULL,NULL,'active',1,'08:00:00','12:00:00','Trinifill Water Station is not accepting online orders at this time. You can contact them or visit the physical store for ordering. Thank you!','2026-05-09 23:18:56');
/*!40000 ALTER TABLE `stores` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `store_id` int(11) DEFAULT NULL,
  `role` enum('superadmin','admin','staff','customer') NOT NULL DEFAULT 'customer',
  `name` varchar(150) NOT NULL,
  `email` varchar(190) NOT NULL,
  `password` varchar(255) NOT NULL,
  `phone` varchar(50) DEFAULT NULL,
  `status` enum('active','disabled') DEFAULT 'active',
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `app_token` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  KEY `idx_app_token` (`app_token`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES
(1,NULL,'superadmin','Super Admin','superadmin@trinifill.local','$2y$10$MVXH3.2.KPSMVRKsP7jeRecYFn7ox4NAzBHIF8b6/5SNVKCOuT.M6','','active',NULL,'2026-05-09 23:18:56',NULL),
(2,1,'admin','Store Owner','owner@trinifill.local','$2y$10$MVXH3.2.KPSMVRKsP7jeRecYFn7ox4NAzBHIF8b6/5SNVKCOuT.M6','1111111111','active',NULL,'2026-05-09 23:18:56','eb1341e8059ebf0c2e070aae2643a078edff7d8e10002b0ad1590c83ab45e2d0'),
(3,1,'staff','Sample Staff','staff@trinifill.local','$2y$10$mSESS/n5qbcIVSEqlh6FO.XedRuaf8MzAryCbUH72kLycCUSa4QSS','3333333333','active',NULL,'2026-05-09 23:18:56','4d0cd669d304e020d2ba0cc1c113cb66d9922d1954fb9fa46284c02ad2a4d1eb'),
(4,1,'customer','Sample Customer','customer@trinifill.local','$2y$10$4jEwkFdBYbErQ0CB8rdWAuaX6q.LzUNB7xisTag5ljy80/NeUZ4Ta','2222222222','active',NULL,'2026-05-09 23:18:56','2c8af58c986f70c83c7e092d0662dfb70b8a967546d05df584b46282af8ea7e0');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-05-11 23:00:02
